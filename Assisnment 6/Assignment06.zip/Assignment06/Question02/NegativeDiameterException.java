package com.sunbeam;

public class NegativeDiameterException extends Exception {
	private String custMessage;
	public NegativeDiameterException() {
		// TODO Auto-generated constructor stub
	}
	public NegativeDiameterException(String custMessage) {
		this.custMessage = custMessage;
	}
	public String getCustMessage() {
		return custMessage;
	}
	public void setCustMessage(String custMessage) {
		this.custMessage = custMessage;
	}
	@Override
	public String getMessage() {
		return this.custMessage!=null ? this.custMessage:"Diameter cannot be Negative";
	}
}
