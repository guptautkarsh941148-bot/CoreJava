package com.sunbeam;

public class Question02 {

	public static void main(String[] args) {
		Circle c1 = new Circle();
		
		try {
			c1.setMyDiameter(-10.32);
		}
		catch(NegativeDiameterException e){
			System.out.println(e.getMessage());
		}
	}

}
