package com.sunbeam;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Question01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.println("Enter the String : ");
			String str  = sc.nextLine();
			if(str.length()>80) {
				throw new ExceptionLineTooLong("The strings is too long");
			}
			else {
				System.out.println("Valid input");
			}
		}
		catch(ExceptionLineTooLong e) {
			System.out.println(e.getMessage());
		}
		finally {
			sc.close();
		}
	}

}
