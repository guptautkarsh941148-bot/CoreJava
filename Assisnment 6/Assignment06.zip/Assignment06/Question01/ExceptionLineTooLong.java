package com.sunbeam;

public class ExceptionLineTooLong extends Exception {
	private String customMessage;
	public ExceptionLineTooLong() {
		// TODO Auto-generated constructor stub
	}
	public ExceptionLineTooLong(String customMessage) {
		this.customMessage = customMessage;
	}

	public String getCustomMessage() {
		return customMessage;
	}
	public void setCustomMessage(String customMessage) {
		this.customMessage = customMessage;
	}
	@Override
	public String getMessage() {
		return "The Strings is too long";
	}

}
